<?php
/*
 Plugin Name: License WP Automatic
 Plugin URI: https://yudhy.net
 Description: WordPress Automatic activate license
 Version: 1.0.0
 Author: yudhy dm
 Author URI: https://yudhy.net
 */

update_option('wp_automatic_license' , '6afcfdc6-323a' );
update_option('wp_automatic_license_active','active');
update_option('wp_automatic_license_active_date',time());
update_option('alb_license_active', '1' );
update_option('alb_license_last', '01-01-2030');
update_option('wp_automatic_envato_token','6afcfdc6-323a');
