<?php
global $wpdb;
$DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
$DB_agc_key = $wpdb->prefix.'agcautopost_key';
include(plugin_dir_path(__FILE__).'FUNC_scrape.php');
$siteurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['HTTP_HOST']."/";
$currurl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$arr_lang = array("ar_SA" => "Arabic","nl_NL" => "Dutch","en_EN" => "English","fr_FR" => "French","de_DE" => "German","id_ID" => "Indonesian","it_IT" => "Italian","ja_JP" => "Japanese","ko_KR" => "Korean","pt_PT" => "Portuguese","ro_RO" => "Romanian","ru_RU" => "Russian","es_ES" => "Spanish","sv_SE" => "Swedish");
$infoz = '';

if(!session_id()){
    session_start();
}

function get_domain($url){
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : '';
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}

if(isset($_POST['keyz_id'])){
    $trimkey = rtrim($_POST['keyz_id'], ',');
    $loopkey = explode(',', $trimkey);
    foreach($loopkey as $dellkey){
        $wpdb->delete($DB_agc_key, array('id' => $dellkey));
    }
}

if(isset($_POST['save_status_rwt'], $_POST['status_rwt'], $_POST['time_post'])){
    $status_cron = $_POST['status_rwt'];
    $time_post = $_POST['time_post'] * 60;
    if($time_post < 300){
        $time_post = 300;
    }
    $savetemp = $wpdb->query("UPDATE $DB_agc_sett SET status_cron = '$status_cron', time_post = '$time_post' WHERE id = '1'");
    if( FALSE === $savetemp ) {
        $infoz = '<div class="alert alert-dismissible alert-danger">Saved <strong>FAILED!</strong></div>';
    } else {
        $infoz = '<div class="alert alert-dismissible alert-success">Saved <strong>SUCCESS.</strong></div>';
    }
}
if(isset($_POST['save_rewrite'], $_POST['post_status'], $_POST['competitors_key'], $_POST['end_lang'], $_POST['tot_lang'], $_POST['auto_key'], $_POST['save_key'])){
    $pos_stat = $_POST['post_status'];
    $wordpost = '';
    $compkeys = $_POST['competitors_key'];
    $end_lang = $_POST['end_lang'];
    $tot_lang = $_POST['tot_lang'];
    $auto_key = $_POST['auto_key'];
    $save_key = $_POST['save_key'];
    $savetemp = $wpdb->query("UPDATE $DB_agc_sett SET post_status = '$pos_stat', word_post = '$wordpost', competitors_key = '$compkeys', end_lang = '$end_lang', tot_lang = '$tot_lang', autosave_key = '$auto_key', char_key = '$save_key' WHERE id = '1'");
    if( FALSE === $savetemp ) {
        $infoz = '<div class="alert alert-dismissible alert-danger">Saved <strong>FAILED!</strong></div>';
    } else {
        $infoz = '<div class="alert alert-dismissible alert-success">Saved <strong>SUCCESS.</strong></div>';
    }
}
if(isset($_POST['save_keywordz'], $_POST['keywordz'], $_POST['cat_key'], $_POST['target_uv'])){
    $target_dt = $_POST['target_uv'];
    $name_pro = $_POST['cat_key'];
    $aterm  = explode("\r\n", $_POST['keywordz']);
    foreach($aterm as $dataz){
		if(empty($dataz)){continue;}
        $inttl      = strtolower(trim($dataz));
        $urls       = str_replace(" ", "-", implode(' ',array_filter(explode(' ',strtolower(seotext(trim($dataz)))))));
        $idtcat     = substr(md5($urls), 1, 9);
        $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $DB_agc_key (idmd5, title, slug, category, target_uv, status) VALUES ( %s, %s, %s, %s, %s, %s )", array($idtcat, $inttl, $urls, $name_pro, $target_dt, '0') ));
    }
}

$cekdom = explode('/', $siteurl);
$thisdom = $cekdom[2];
$domserver = "https://infinity.agcscript.cyou/";

if(isset($_POST['activated_license'], $_POST['license'])){
    $lisensi = '123456789';
    $getjsonc = '{"status":"200"}';
    $jsondata = json_decode($getjsonc, TRUE);
    $statuspg = $jsondata['status'];
    if($statuspg == 200){
        $_SESSION['lisensi_agc'] = 200;
        $_SESSION['lisensi_exp'] = time();
        $wpdb->query("UPDATE $DB_agc_sett SET idkey = '$lisensi' WHERE id = '1'");
    }else{
        echo '<script>alert("'.$statuspg.'");window.location.reload();</script>';
    }
}

foreach($wpdb->get_results( "SELECT * FROM $DB_agc_sett WHERE id = '1'") as $key => $row) {
    $cron_status = $row->status_cron;
    $end_lang = $row->end_lang;
    $tot_lang = $row->tot_lang;
    $time_post = $row->time_post / 60;
    $auto_key = $row->autosave_key;
    $save_key = $row->char_key;
    $word_post = $row->word_post;
    $competitors_key = $row->competitors_key;
    $posts_status = $row->post_status;
    $lisensi = $row->idkey;
}

if(empty($lisensi)){
?>
<div id="container">
    <h1>Masukkan Lisensi Member</h1>
    <p>Pastikan nama domain <b style="color:#ff3636;"><?php echo strtoupper($thisdom); ?></b> didaftarkan ke Lisensi Domain. <a href="<?php echo $domserver; ?>member/dashboard" target="_blank" style="font-weight:700;">Login Member Area</a></p>
    <?php echo $infoz; ?>
    <form name="add_license" method="POST" action="" onsubmit="return LicenseValForm()">
        <ul>
            <li>
                <label for="flic">License Code</label><br>
                <input type="text" name="license" style="width:350px;" />
            </li>
            <li style="margin-top:10px;">
                <input type="submit" name="activated_license" value="Submit" />
            </li>
        </ul>
    </form>
</div>
<script>
function LicenseValForm(){
    let lics = document.forms["add_license"]["license"].value;
    if(lics == ""){alert("Lisensi wajib di isi");return false;}
}
</script>
<?php
exit();
}else{
    if( (!isset($_SESSION['lisensi_agc'])) && (!isset($_SESSION['lisensi_exp'])) ){
        $getjsonc = '{"status":"200"}';
        $jsondata = json_decode($getjsonc, TRUE);
        $statuspg = $jsondata['status'];
        if($statuspg != 200){
            $wpdb->query("UPDATE $DB_agc_sett SET status_cron = 'off', idkey = '' WHERE id = '1'");
            header("Location: ".$currurl);
            exit();
        }else{
            $_SESSION['lisensi_exp'] = time();
            $_SESSION['lisensi_agc'] = 200;
        }
    }else{
        if(time() - $_SESSION['lisensi_exp'] > 300){
            unset($_SESSION['lisensi_agc']);
            unset($_SESSION['lisensi_exp']);
            $getjsonc = '{"status":"200"}';
            $jsondata = json_decode($getjsonc, TRUE);
            $_SESSION['lisensi_agc'] = $jsondata['status'];
            $_SESSION['lisensi_exp'] = time();
        }else{
            if($_SESSION['lisensi_agc'] != 200){
                unset($_SESSION['lisensi_agc']);
                unset($_SESSION['lisensi_exp']);
                $wpdb->query("UPDATE $DB_agc_sett SET status_cron = 'off', idkey = '' WHERE id = '1'");
                header("Location: ".$currurl);
                exit();
            }
        }
    }
}

$auto_status = '<option value="off">OFF</option><option value="on">ON</option>';
$auto_status = preg_replace('/value="'.$cron_status.'"/', 'value="'.$cron_status.'" selected', $auto_status);

$loop_lang = '<option value="3">3 Loop</option><option value="4">4 Loop</option><option value="5">5 Loop</option>';
$loop_lang = preg_replace('/value="'.$tot_lang.'"/', 'value="'.$tot_lang.'" selected', $loop_lang);

$auto_keys = '<option value="off">OFF</option><option value="on">ON</option>';
$auto_keys = preg_replace('/value="'.$auto_key.'"/', 'value="'.$auto_key.'" selected', $auto_keys);

$save_keys = '<option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option>';
$save_keys = preg_replace('/value="'.$save_key.'"/', 'value="'.$save_key.'" selected', $save_keys);

$competitors_keys = '<option value="off">OFF</option><option value="on">ON</option>';
$competitors_keys = preg_replace('/value="'.$competitors_key.'"/', 'value="'.$competitors_key.'" selected', $competitors_keys);

$post_status = '<option value="future">Publish</option><option value="draft">Draft</option>';
$post_status = preg_replace('/value="'.$posts_status.'"/', 'value="'.$posts_status.'" selected', $post_status);

$exphl = explode('_', $end_lang);

?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo $siteurl; ?>wp-content/plugins/agc-by-keywords/asset/dataTables.bootstrap.min.css" />
<script type="text/javascript" src="<?php echo $siteurl; ?>wp-content/plugins/agc-by-keywords/asset/jquery-3.5.1.js"></script>
<script type="text/javascript" src="<?php echo $siteurl; ?>wp-content/plugins/agc-by-keywords/asset/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo $siteurl; ?>wp-content/plugins/agc-by-keywords/asset/dataTables.bootstrap.min.js"></script>
<link rel="stylesheet" href="<?php echo $siteurl; ?>wp-content/plugins/agc-by-keywords/asset/select.dataTables.min.css" />
<script type="text/javascript" src="<?php echo $siteurl; ?>wp-content/plugins/agc-by-keywords/asset/dataTables.select.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
#drp_table_wrapper{margin-top: 20px;}
table.dataTable tr th.select-checkbox.selected::after {
    content: "✔";
    margin-top: -11px;
    margin-left: -4px;
    text-align: center;
    text-shadow: rgb(176, 190, 217) 1px 1px, rgb(176, 190, 217) -1px -1px, rgb(176, 190, 217) 1px -1px, rgb(176, 190, 217) -1px 1px;
}
</style>
        <script src="https://code.jquery.com/jquery-1.7.2.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.js"></script>
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
        <meta http-equiv="CACHE-CONTROL" content="NO-CACHE">
        <script type='text/javascript'>//<![CDATA[ 
        var jq = $.noConflict();
        jq(function(){
        jq(document).ready(function () {
            jq("#suggest").autocomplete({
                delay: 100,
                source: function (request, response) {
                    var suggestURL = "//suggestqueries.google.com/complete/search?client=firefox&cp=2&hl=<?php echo $exphl[0]; ?>&q=%QUERY";
                    suggestURL = suggestURL.replace('%QUERY', request.term);
                    
                    jq.ajax({
                        method: 'GET',
                        dataType: 'jsonp',
                        jsonpCallback: 'jsonCallback',
                        url: suggestURL
                    })
                    .success(function(data){
                        response(data[1]);
                    });
                }
            });
        });
        });//]]>
        </script>
<div class="container" style="width:97%;margin-bottom:50px;">

	<div class="col-lg-12">
		<h2 style="font-size:2.1rem;font-weight:700;"><span style="color:#d7d7d7;font-size:1.8em;font-weight:900;">AGC</span><span style="color:#b1b1b1;">AutoPost by Keywords</span></h2>
		<p style="text-align:right;margin-top:-25px;"><button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#ModalAutoPost" style="font-weight:700;background-color:#bd1212;border-color:#ed7b7b;">DOCUMENTATION</button>
        <div id="infoz"><?php echo $infoz; ?></div>

        <div class="row" style="margin:0;margin-top:2em;">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12" style="">
                        <h3 style="font-size:1.2em;font-weight:700;">Timer & Cron Auto Post</h3>
                    </div>
                    <div class="col-md-12" style="background:#e7e7e7;border:1px solid #d1d1d1;margin-bottom:15px;padding-bottom:5px;">
                        <form class="form-inline" action="" method="post">
                            <div class="form-group" style="margin-top:5px;">
                                <div class="input-group" style="">
                                    <span class="input-group-addon" style="background:none;border:0;padding-left:0px;padding-right:5px;">Automatic post timing in</span>
                                    <input type="number" class="form-control" style="max-width:55px;" id="input3" min="5" name="time_post" value="<?php echo $time_post; ?>" required>
                                    <span class="input-group-addon" style="background:none;border:0;padding-left:5px;padding-right:0px;">minutes</span>
                                </div>
                                <div class="input-group" style="margin-right:10px;">
                                    <span class="input-group-addon" style="background:none;border:0;padding-left:0px;padding-right:5px;">and status automatic post cronjobs</span>
                                    <select class="form-control" name="status_rwt" required>
                                        <?php echo $auto_status; ?>
                                    </select>
                                </div>
                                <div class="input-group">
                                    <button type="submit" class="btn btn-sm btn-primary" name="save_status_rwt">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="row" style="margin:0;margin-top:2em;">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12" style="">
                        <h3 style="font-size:1.2em;font-weight:700;">Setting Data Post</h3>
                    </div>
                <div class="col-md-12" style="background:#e7e7e7;border:1px solid #d1d1d1;">
            	<div class="panel-body">
                    <form class="form-horizontal" action="" method="post">
                        <div class="form-group">
                            <label for="select0" class="col-lg-5 control-label" style="text-align:left;padding-left:0px;">Status Post Article</label>
                            <div class="col-lg-7">
                                <select class="form-control" name="post_status" id="select0" required>
                                    <?php echo $post_status; ?>
                                </select>
                                <span class="help-block" style="font-size:0.8em;">choose post status</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select1" class="col-lg-5 control-label" style="text-align:left;padding-left:0px;">Output Language</label>
                            <div class="col-lg-7">
                                <select class="form-control" id="select1" name="end_lang">
<?php
foreach($arr_lang as $val1 => $key1){
    $langx1 .= '<option value="'.$val1.'">'.$key1.'</option>';
}
echo preg_replace('/value="'.$end_lang.'"/', 'value="'.$end_lang.'" selected', $langx1);

?>
                                </select>
                                <span class="help-block" style="font-size:0.8em;">select the last language for content</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select2" class="col-lg-5 control-label" style="text-align:left;padding-left:0px;">Looping Rewrite</label>
                            <div class="col-lg-7">
                                <select class="form-control" id="select2" name="tot_lang">
                                    <?php echo $loop_lang; ?>
                                </select>
                                <span class="help-block" style="font-size:0.8em;">total looping rewrite content</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12" style="padding-left:0;margin-bottom:20px;">
                                <h3 style="font-size:1.2em;font-weight:700;color:#bb0606;">Setting Suggest Keywords</h3>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select3" class="col-lg-5 control-label" style="text-align:left;padding-left:0px;">Post Suggest Key</label>
                            <div class="col-lg-7">
                                <select class="form-control" id="select3" name="auto_key">
                                    <?php echo $auto_keys; ?>
                                </select>
                                <span class="help-block" style="font-size:0.8em;">autopost if suggest keywords is on</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select5" class="col-lg-5 control-label" style="text-align:left;padding-left:0px;">Related Keywords</label>
                            <div class="col-lg-7">
                                <select class="form-control" id="select5" name="competitors_key">
                                    <?php echo $competitors_keys; ?>
                                </select>
                                <span class="help-block" style="font-size:0.8em;">insert related keyword in last article</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="select4" class="col-lg-5 control-label" style="text-align:left;padding-left:0px;">Suggest Characters</label>
                            <div class="col-lg-7">
                                <select class="form-control" id="select4" name="save_key">
                                    <?php echo $save_keys; ?>
                                </select>
                                <span class="help-block" style="font-size:0.8em;">minimum save suggest key characters</span>
                            </div>
                        </div>
                        <div class="form-group" style="margin-top:45px;text-align:right;margin-right:0px;">
                            <button type="submit" class="btn btn-sm btn-primary" name="save_rewrite">Save</button>
                        </div>
                    </form>
            	</div>
            	
            	</div>
            	</div>
            	
        	</div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12" style="">
                        <h3 style="font-size:1.2em;font-weight:700;">Single Keyword Post</h3>
                    </div>
                    <div class="col-md-12" style="background:#d3d3d3;border:1px solid #c1c1c1;">
                    	<div class="panel-body">
                            <form class="form-horizontal" action="<?php echo $siteurl; ?>single_autopost/" method="post" target="_blank">
                                <div class="form-group" style="margin-bottom:0px;">
                                    <input type="text" class="form-control" name="single_key" placeholder="insert keywords" id="suggest" required>
                                    <span class="help-block" style="font-size:0.8em;">insert single keyword</span>
                                </div>
                                <div class="form-group" style="margin-bottom:0px;">
                                    <div class="row">
                                    <div class="col-lg-6">
                                        <label class="control-label">Category</label>
                                        <select class="form-control" name="cat_key" required>
                                            <option value="" selected>Category</option>
        <?php
        $terms = get_terms(
            array(
                'taxonomy'   => 'category',
                'hide_empty' => false,
            )
        );
        if(!empty($terms) && is_array($terms)){
            foreach($terms as $term){ 
                echo '<option value="'.$term->term_id.'">'.$term->name.'</option>';
            }
        }
        ?>
                                        </select>
                                        <span class="help-block" style="font-size:0.8em;">keyword category</span>
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="control-label">Article Method</label>
                                        <select class="form-control" name="target_uv" required>
                                            <?php echo '<option value="" selected>Target</option><option value="off">Only Content</option><option value="single">One Images</option><option value="images">Images Content</option><option value="web">Web Content</option>'; ?>
                                        </select>
                                        <span class="help-block" style="font-size:0.8em;">global method for article</span>
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group" style="margin-top:0px;text-align:right;margin-right:0px;">
                                    <button type="submit" class="btn btn-sm btn-primary" name="save_single_key">Submit</button>
                                </div>
                            </form>
                        </div>
            	    </div>
            	    
                    <div class="col-md-12" style="">
                        <h3 style="font-size:1.2em;font-weight:700;">Mass Cronjobs Keyword Post</h3>
                    </div>
                    <div class="col-md-12" style="background:#d3d3d3;border:1px solid #c1c1c1;">
                    	<div class="panel-body">
                            <form class="form-horizontal" action="" method="post">
                                <div class="form-group" style="margin-bottom:0px;">
                                    <textarea name="keywordz" class="form-control" rows="8" type="textarea"></textarea>
                                    <span class="help-block" style="font-size:0.8em;">separate with new line</span>
                                </div>
                                <div class="form-group" style="margin-bottom:0px;">
                                    <div class="row">
                                    <div class="col-lg-6">
                                        <label class="control-label">Category</label>
                                        <select class="form-control" name="cat_key" required>
                                            <option value="" selected>Category</option>
<?php
$terms = get_terms(
    array(
        'taxonomy'   => 'category',
        'hide_empty' => false,
    )
);
if(!empty($terms) && is_array($terms)){
    foreach($terms as $term){ 
        echo '<option value="'.$term->term_id.'">'.$term->name.'</option>';
    }
} 
?>
                                        </select>
                                        <span class="help-block" style="font-size:0.8em;">keyword category</span>
                                    </div>
                                    <div class="col-lg-6">
                                        <label class="control-label">Article Method</label>
                                        <select class="form-control" name="target_uv" required>
                                            <?php echo '<option value="" selected>Target</option><option value="off">Only Content</option><option value="single">One Images</option><option value="images">Images Content</option><option value="web">Web Content</option>'; ?>
                                        </select>
                                        <span class="help-block" style="font-size:0.8em;">global method for article</span>
                                    </div>
                                    </div>
                                </div>
                                <div class="form-group" style="margin-top:0px;text-align:right;margin-right:0px;">
                                    <button type="submit" class="btn btn-sm btn-primary" name="save_keywordz">Submit</button>
                                </div>
                            </form>
                        </div>
            	    </div>
        	    </div>
        	</div>
        </div>
        
    <div class="row" style="margin-top:2em;">
        <div class="col-lg-6">
            <h3 style="font-size:1.8em;font-weight:700;color:#6f973a;display:inline-block;">List Data Keywords</h3>
        </div>
        <div class="col-lg-4" style="text-align:right;">
            <form action="<?php echo $siteurl; ?>single_autopost/" method="post" target="_blank">
            <div class="form-group" style="margin-top:20px;">
                <div class="input-group">
                    <select class="form-control-sm" style="float:right;border-color:#df2b25;" name="datakey" required>
                        <option value="">Download Keywords</option>
                        <option value="0">Download NO Posted Keywords</option>
                        <option value="1">Download YES Posted Keywords</option>
                        <option value="all">Download ALL Keywords</option>
                    </select>
                    <span class="input-group-btn">
                        <button class="btn btn-sm btn-danger" type="submit" name="download_key">Downloads</button>
                    </span>
                </div>
            </div>
            </form>
        </div>
        <div class="col-lg-2" style="text-align:right;">
            <a href="<?php echo $currurl; ?>" class="btn btn-sm btn-default" style="margin-top:20px;background-color:#d7d7d7;"><i class="fa fa-refresh"></i> Refresh</a>
        </div>
    </div>
    <div class="row" style="margin-top:2em;">
        <div class="col-lg-12">
            <form action="" method="">
            <div class="table-responsive">
            <table id="agc_ap_table" class="table table-striped table-bordered" style="width:100%;margin-top:30px;">
                <thead>
                    <tr>
                        <th style="text-align:center;"></th>
                        <th style="display:none;"></th>
                        <th style="text-align:left;">Title</th>
                        <th style="text-align:center;">IDkey</th>
                        <th style="text-align:center;">Category</th>
                        <th style="text-align:center;">LongKey</th>
                        <th style="text-align:center;">Target</th>
                        <th style="text-align:center;">Posted</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th style="text-align:center;"></th>
                        <th style="display:none;"></th>
                        <th style="text-align:left;">Title</th>
                        <th style="text-align:center;">IDkey</th>
                        <th style="text-align:center;">Category</th>
                        <th style="text-align:center;">LongKey</th>
                        <th style="text-align:center;">Target</th>
                        <th style="text-align:center;">Posted</th>
                    </tr>
                </tfoot>
                <tbody>
<?php
foreach($wpdb->get_results("SELECT * FROM $DB_agc_key") as $key => $krow) {
    $idkey = $krow->id;
    $tlkey = $krow->title;
    $ctkey = $krow->category;
    $trkey = $krow->target_uv;
    $stkey = $krow->status;
    if(preg_match('/0/', $stkey)){
        $stkey = 'No';
    }else{
        $stkey = 'Yes';
    }
    $longkey = count(explode(' ', trim($tlkey)));
    $catnm = get_cat_name($ctkey);
    if(preg_match('/^off$/', $trkey)){
        $targetz = 'Only Content';
    }elseif(preg_match('/^single$/', $trkey)){
        $targetz = 'One Images';
    }elseif(preg_match('/^images$/', $trkey)){
        $targetz = 'Images Content';
    }elseif(preg_match('/^web$/', $trkey)){
        $targetz = 'Web Content';
    }
    echo '<tr data-keyid="'.$idkey.'">
        <td style="text-align:center;"></td>
        <td style="display:none;">'.$idkey.'</td>
        <td>'.ucwords($tlkey).'</td>
        <td style="text-align:center;">'.$idkey.'</td>
        <td style="text-align:center;">'.$catnm.'</td>
        <td style="text-align:center;">'.$longkey.'</td>
        <td style="text-align:center;">'.$targetz.'</td>
        <td style="text-align:center;">'.$stkey.'</td>
    </tr>';
    
}
?>
                </tbody>
            </table>
            </div>
            <button type="button" class="btn btn-sm btn-danger" id="dell_mkey">Remove Key</button>
            </form>
        </div>
    </div>

    </div>

<form action="" method="post" id="dell_keyz"></form>

<div class="modal" id="ModalAutoPost">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="text-align:center;">
                <h3 class="modal-title" style="font-weight:700;color:#25738b;">Documentation : Plugin Autopost by Keywords</h3>
            </div>
            <div class="modal-body">
                <p><strong>Plugin Autopost by Keywords</strong> adalah plugin yang mempermudah untuk membuat artikel secara massal. Dengan sistem cronjobs dan rewrite 
                secara otomatis serta artikel yang juga lebih bisa dibaca, tentu akan mempermudah pembaca seakan konten artikel yang dibuat secara manual.</p>
                <p>Berikut fitur dan fungsi di <strong>Plugin Autopost by Keywords</strong></p>
                
                <h3 style="font-size:14px;font-weight:700;color:#25738b;margin-bottom:0px;margin-top:0px;">Timer & Cron Auto Post</h3>
                <div class="panel panel-default" style="background-color:#e5e5e5;"><div class="panel-body">
                    <p style="margin-bottom:0px;">Pengaturan yang berfungsi untuk mengatur waktu autopost dan pengaturan ON/OFF autopost. Dan minimal jeda posting secara otomatis adalah 5 menit.</p>
                    <p style="margin-bottom:0px;">Pengaturan autopost akan berjalan jika list keywords sudah di isi.</p>
                </div></div>
                
                <h3 style="font-size:14px;font-weight:700;color:#25738b;margin-bottom:0px;margin-top:0px;">Setting Data Post</h3>
                <div class="panel panel-default" style="background-color:#e5e5e5;"><div class="panel-body">
                    <p>Pengaturan Data Post berfungsi untuk mengatur semua sistem di plugin Autopost by Keywords, jadi silahkan atur terlebih dahulu pengaturan data post agar bisa sesuai dengan yang di inginkan.</p>
                    <p style=""><strong style="color:#dd2525;">Status Post Article :</strong> Atur status post artikel akan diterbitkan sekarang atau disimpan sebagai draft.</p>
                    <p style=""><strong style="color:#dd2525;">Output Language :</strong> Bahasa artikel yang nantinya akan diposting.</p>
                    <p style=""><strong style="color:#dd2525;">Looping Rewrite :</strong> Pengaturan ini untuk sistem rewrite diulang berapa kali, secara default 4 loop.</p>
                    <p style=""><strong style="color:#dd2525;">Post Suggest Key :</strong> Jika memilih ON, saat kata kunci digenerate menjadi artikel nantinya plugin otomatis akan mencari kata kunci yang terkait dan auto tersimpan di list keywords.</p>
                    <p style=""><strong style="color:#dd2525;">Related Keywords :</strong> Posisi ON nantinya kalimat artikel paling akhir yang sudah terposting akan muncul suggestion keyword berdasarkan judul.</p>
                    <p style="margin-bottom:0px;"><strong style="color:#dd2525;">Suggest Characters :</strong> Pengaturan ini berfungsi untuk filter Post Suggest Key jika posisi ON.<br>
                    Minimal berapa kata yang akan disimpan ke list keywords.</p>
                </div></div>
                
                <h3 style="font-size:14px;font-weight:700;color:#25738b;margin-bottom:0px;margin-top:0px;">Single Keyword Post</h3>
                <div class="panel panel-default" style="background-color:#e5e5e5;"><div class="panel-body">
                    <p style="margin-bottom:0px;">Gunakan tool single keyword jika ingin membuat artikel secara satu persatu. Masukkan kata kunci sebagai judul dan pilih kategori serta target model artikelnya.<br>
                    Ada 4 pilihan Only Content, One Images, Images Content, Web Content.</p>
                </div></div>
                
                <h3 style="font-size:14px;font-weight:700;color:#25738b;margin-bottom:0px;margin-top:0px;">Mass Cronjobs Keyword Post</h3>
                <div class="panel panel-default" style="background-color:#e5e5e5;"><div class="panel-body">
                    <p style="margin-bottom:0px;">Untuk membuat artikel secara otomatis silahkan masukkan koleksi kata kunci ke kolom textarea.<br>
                    Semua kata kunci yang tersimpan nantinya akan di buat artikel oleh plugin secara otomatis. Waktu posting tergantung dari pengaturan di Timer & Cron Auto Post.<br>
                    Pilih kategori dan target metode artikel sesuai dengan kata kunci yang dimasukkan.</p>
                </div></div>
                
                <h3 style="font-size:14px;font-weight:700;color:#25738b;margin-bottom:0px;margin-top:0px;">List Data Keywords</h3>
                <div class="panel panel-default" style="background-color:#e5e5e5;"><div class="panel-body">
                    <p style="margin-bottom:0px;">Bagian Data List Keywords adalah hasil kata kunci massal dan pengaturan Post Suggest Key.<br>
                Anda juga bisa download koleksi kata kunci di list keywords pada tombol download.</p>
                </div></div>
                
                <p>Untuk penambahan Lisensi atau support, langsung PM <strong>FB Mesengger : <a href="https://m.me/AGCscript/" target="_blank">m.me/AGCscript</a></strong></p>
                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<script>
$(document).ready(function(){
    let agcap = $('#agc_ap_table').DataTable({
        aLengthMenu: [[25, 50, 75, 100, 200, 300, -1], [25, 50, 75, 100, 200, 300, "All"]],
        iDisplayLength: 25,
        columnDefs: [{
            targets: 0,
            orderable: false,
            className: 'select-checkbox'
        }],
        select: {
            style: 'multi',
            selector: 'td:first-child'
        },
        order: [
            [1, 'asc']
        ]
    });

    agcap.on("click", "th.select-checkbox", function() {
        if ($("th.select-checkbox").hasClass("selected")) {
            agcap.rows().deselect();
            $("th.select-checkbox").removeClass("selected");
        } else {
            agcap.rows().select();
            $("th.select-checkbox").addClass("selected");
        }
    }).on("select deselect", function() {
        ("Some selection or deselection going on")
        if (agcap.rows({
                selected: true
            }).count() !== agcap.rows().count()) {
            $("th.select-checkbox").removeClass("selected");
        } else {
            $("th.select-checkbox").addClass("selected");
        }
    });
    
    $('#dell_mkey').click(function () {
        var idkeyz = '';
        $("tr.selected").each(function(){
            idkeyz += $(this).attr("data-keyid")+',';
        });
        
        $('#dell_keyz').append(
            $('<input>').attr('type', 'hidden').attr('name', 'keyz_id').val(idkeyz)
        );
        
        var coms = idkeyz.split(",");
        var totq = coms.slice(0, -1).length;
        if(totq == 0){alert('Opsss... Please choose your keywords');return false;}
        let delt = "Total Remove : "+ coms.slice(0, -1).length +" Keywords";
        if(confirm(delt) == true){
            $('#dell_keyz').submit();
        }else{
            return false;
        }
        
    });
    $('#infoz').delay(3000).fadeOut(1000);
});
</script>
</div>