<?php
/*
Plugin Name: AGC by Keywords
Plugin URI: https://infinity.agcscript.cyou/
Description: Full Rewrite and Auto Post by Keywords
Author: AGC SCRIPT
Version: 1.0
Author URI: https://www.facebook.com/AGCscript/
*/
ob_start();
session_start();
add_action('admin_menu', 'agc_autopost_admin');
function agc_autopost_admin(){
    add_menu_page(
        'AGC AutoPost',
        'AGC AutoPost',
        'manage_options',
        'agcautopost',
        'agc_autopost_init',
        'dashicons-image-filter',
        '2'
    );
}
function agc_autopost_init(){
    include('agc_autopost.php');
}

function agc_autopost_sett() {
    global $wpdb;
    $DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
    if($wpdb->get_var("SHOW TABLES LIKE '$DB_agc_sett';") != $DB_agc_sett) {
        $charset_collate = $wpdb->get_charset_collate();
   		$sql = "CREATE TABLE $DB_agc_sett (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`post_status` varchar(50) NOT NULL,
		`end_lang` varchar(10) NOT NULL,
		`tot_lang` varchar(10) NOT NULL,
		`word_post` varchar(10) NOT NULL,
		`status_cron` varchar(10) NOT NULL,
		`autosave_key` varchar(10) NOT NULL,
		`char_key` varchar(10) NOT NULL,
		`time_post` varchar(10) NOT NULL,
		`competitors_key` varchar(10) NOT NULL,
		`idkey` varchar(50) NOT NULL,
		PRIMARY KEY (`id`)
		) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
   }
   $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $DB_agc_sett (id, post_status, end_lang, tot_lang, word_post, status_cron, autosave_key, char_key, time_post, competitors_key, idkey) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s )", array('1', 'publish', 'id_ID', '4', '1500', 'off', 'off', '5', '600', 'on', '') ));
}
register_activation_hook(__FILE__,'agc_autopost_sett');

function agc_autopost_key() {
    global $wpdb;
    $DB_agc_key = $wpdb->prefix.'agcautopost_key';
    if($wpdb->get_var("SHOW TABLES LIKE '$DB_agc_key';") != $DB_agc_key) {
        $charset_collate = $wpdb->get_charset_collate();
   		$sql = "CREATE TABLE $DB_agc_key (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`idmd5` varchar(50) CHARACTER SET latin1 NOT NULL,
		`title` text COLLATE utf8mb4_unicode_ci NOT NULL,
		`slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
		`category` varchar(10) NOT NULL,
		`target_uv` varchar(10) NOT NULL,
		`status` varchar(10) NOT NULL,
		PRIMARY KEY (`id`),
		UNIQUE KEY `idmd5` (`idmd5`)
		) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
   }
}
register_activation_hook(__FILE__,'agc_autopost_key');

add_filter( 'cron_schedules', 'cron_aap' );
function cron_aap( $schedules ) {
    global $wpdb;
    $DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
    $sett_sql = $wpdb->get_results("SELECT * FROM  $DB_agc_sett WHERE id = '1'");
    foreach($sett_sql as $datasett){
        $timepost = $datasett->time_post;
        $statuscron = $datasett->status_cron;
    }
    if(preg_match('/^on$/', $statuscron)){
        $cnminute = $timepost / 60;
        $schedules['cron_agcautopost'] = array(
                'interval'  => $timepost,
                'display'   => __( 'Scrape AGC AutoPost '.$cnminute.' Minutes', 'textdomain' )
        );
    }
    return $schedules;
}
if ( ! wp_next_scheduled( 'cron_aap' ) ) {
    wp_schedule_event( time(), 'cron_agcautopost', 'cron_aap' );
}
add_action("init", "clear_cron_aap");
function clear_cron_aap() {
    global $wpdb;
    $DB_agc_sett = $wpdb->prefix.'agcautopost_sett';
    $sett_sql = $wpdb->get_results("SELECT * FROM  $DB_agc_sett WHERE id = '1'");
    foreach($sett_sql as $datasett){
        $statuscron = $datasett->status_cron;
    }
    if(preg_match('/^off$/', $statuscron)){
        wp_clear_scheduled_hook('cron_aap');
    }
}
add_action( 'cron_aap', 'cron_aap_func' );
function cron_aap_func() {
    include(plugin_dir_path(__FILE__).'___cron_aap_func.php');
}

add_filter('theme_page_templates', 'tes_idx');
add_filter('template_include', 'tes_idx_include', 99);
function tes_idx($templates){
    $templates[plugin_dir_path(__FILE__) . 'TES_index.php'] = __('Plugin AutoPost Single Keywords', 'single_autopost');
    return $templates;
}
function tes_idx_include($template){
    if (is_page('single_autopost')) {
        $meta = get_post_meta(get_the_ID());
        if (!empty($meta['_wp_page_template'][0]) && $meta['_wp_page_template'][0] != $template) {
            $template = $meta['_wp_page_template'][0];
        }
    }
    return $template;
}
function page_single_autopost() {
    $pagez = array(
        'post_title' => 'Plugin AutoPost Single Keywords',
        'post_content' => 'Jangan Di Edit',
        'post_name' => 'single_autopost',
        'post_status' => 'private',
        'post_author' => 1,
        'post_type' => 'page',
        'post_slug' => 'single_autopost',
        'page_template' => WP_PLUGIN_DIR . '/agc-by-keywords/TES_index.php'
    );
    if(get_page_by_path('single_autopost', OBJECT) == NULL){
        wp_insert_post( $pagez, $wp_error = false );
    }else{
        return false;
    }
}
register_activation_hook(__FILE__, 'page_single_autopost');
ob_end_flush();
?>