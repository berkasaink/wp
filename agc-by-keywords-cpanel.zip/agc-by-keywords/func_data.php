<?php
ob_start();
session_start();
function contents_web($url, $min_space, $min_letter){
    $url = preg_replace('/\?page=/', '', $url).'?page=all';
    $exp_url = explode('/', $url);
    $seourl1 = preg_replace('/www\./', '', $exp_url[2]);
    $seourl2 = preg_replace('/\.(.*)/', '', $seourl1);
    $reff = 'https://'.$exp_url[2].'/';
    $options = array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER         => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING       => "",
        CURLOPT_USERAGENT      => "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36",
        CURLOPT_REFERER        => $reff,
        CURLOPT_AUTOREFERER    => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_MAXREDIRS      => 2,
        CURLOPT_SSL_VERIFYPEER => false
    );
    $ch = curl_init( $url );
    curl_setopt_array( $ch, $options );
    $htmlx = curl_exec( $ch );
    if(curl_errno($ch)){
        $result = 'curl error';
        return $result;
    }
    curl_close( $ch );
    if(!empty($htmlx)){
        $html = str_get_html($htmlx);
        if(empty($html)){
            $result = 'str html error';
            return $result;
        }
        $html = $html->find('body',0)->outertext;
        $html = str_get_html($html);
        foreach($html->find('li,ins,script,noscript,comment,form,nav,header,footer,iframe,style,pre,date,[id^=related],[class^=related],[id^=header],[class^=header],[id^=sidebar],[class^=sidebar],[id^=footer],[class^=footer],[id^=copyright],[class^=copyright],[id^=comments],[class^=comments],[id^=comment],[class^=comment]') as $del){
            if(isset($del)){
                $del->outertext = "";
            }
        }
        foreach($html->find('h1, h2, h3, h4, h5, h6, strong, b, i, a, small, u, blockquote, span') as $str){
            $getext = $str->plaintext;
            $str->outertext = $getext;
        }
        preg_match_all('/>[^>^<]*</', $html, $ifhaz);
        if(empty($ifhaz[0][0])){
            $result = 'error preg_match';
            return $result;
        }
        $isdesc = array();
        foreach($ifhaz[0] as $ifhas){
            $ifhas = preg_replace('/><|>\s{1,}</', '', $ifhas);
            if(empty($ifhas)){continue;}
            $ifhas = trim(preg_replace('/\s{1,}/', ' ', preg_replace('/^>|<$|\{(.*?)\}/', '', $ifhas)));
            $ifhas = preg_replace('/'.$exp_url[2].'|'.$seourl1.'|'.$seourl2.'/i', '', $ifhas);
            $ifhas = preg_replace('/^\s-\s|^-\s|^\s-|^-|\[\{|\}\]/', '', $ifhas);
            $ifhas = str_replace('&nbsp;', '', $ifhas);
            $exhas = explode(' ', $ifhas);
            if(count($exhas) < $min_space){continue;}
            if(strlen($ifhas) < $min_letter){continue;}
            $isdesc[] = html_entity_decode(trim($ifhas));
        }
        $isdesc = array_unique($isdesc);
        $pozting = '';
        foreach($isdesc as $isdesc){
            //$pozting .= '<p>'.$isdesc.'</p>';
            $pozting .= $isdesc."<br>";
        }
        $result = rtrim($pozting, "<br>");
        return $result;
    }else{
        $result = 'empty curl';
        return $result;
    }
}           

function images_data($key){
    $IMGkey = urlencode(potong_kata(seotext($key),8));
    $IMGurl = "https://www.google.com/search?q={$IMGkey}&tbm=isch&hl=en-US&tbs=isz:l&sa=X&biw=1349&bih=657";
	$options = stream_context_create(array('http'=> array('user_agent' => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36', 'timeout' => 3) ));
    $content = file_get_contents($IMGurl, false, $options);
    $getstr = mb_convert_encoding($content, 'UTF-8', mb_detect_encoding($content, 'UTF-8, ISO-8859-1', true));
    preg_match_all('/\[1,\[0,"(.*?)"\]\}\],/', $getstr, $pozlinkz);
    $source = array();
    $title = array();
    $image = array();
    $thumb = array();
    foreach($pozlinkz[0] as $pozlink){
    	$eimg = explode('],["', $pozlink);
    	$xtmb = UTF8escape(preg_replace('/.*",\["|".*/', '', $eimg[0]));
    	$ximg = UTF8escape(preg_replace('/".*/', '', $eimg[1]));
    	$ettl = explode('","', $pozlink);
    	$xurl = UTF8escape(preg_replace('/.*"/', '', $ettl[1]));
    	$xttl = UTF8escape(preg_replace('/".*/', '', $ettl[2]));
        $xttl = preg_replace('/\s\|\s.*|\s-\s.*|\s\~\s.*|\s:\s.*|\s–\s.*|\s\.{3}$/', ' ', $xttl);
        $xttl = preg_replace('/^[^\w]*/', '', $xttl);
    	$xttl = preg_replace('/^[^a-zA-ZäöüÄÖÜßàâçéèêëîïôûùüÿñæœ]*|\.+$/', '', $xttl);
        $xttl = trim(preg_replace('/\s{1,}/', ' ', str_replace("-", ' ', $xttl)));
        if(preg_match('/youtube\.|facebook\.|instagram\.|twitter\.|pinterest\.|tiktok\./i', $xurl)){continue;}
        if(preg_match('/^(https|http):\/\//i', $xttl)){continue;}
        $source[] = $xurl;
        $title[] = $xttl;
        $image[] = $ximg;
        $thumb[] = $xtmb;
    }
    $source = array_unique($source);
    $title = array_unique($title);
    $image = array_unique($image);
    $thumb = array_unique($thumb);
    
    $source = array_filter($source, function($value){
        return preg_match('/^(?!.*(youtube\.|facebook\.|instagram\.|twitter\.|pinterest\.))/', $value);
    });
    $title = array_filter($title, function($value){
        return preg_match('/^(?!.*(https:|http:))/', $value);
    });
    $dataz = array("source" => $source, "title" => $title, "image" => $image, "thumb" => $thumb);
    return json_encode($dataz, JSON_HEX_APOS | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

class GoogleTranslate
{
    public static function translate($source, $target, $text) {
        $response = self::requestTranslation($source, $target, $text);
        $translation = self::getSentencesFromJSON($response);
        return $translation;
    }
    protected static function requestTranslation($source, $target, $text) {
        $url = "https://translate.google.com/translate_a/single?client=at&dt=t&dt=ld&dt=qca&dt=rm&dt=bd&dj=1&hl=es-ES&ie=UTF-8&oe=UTF-8&inputm=2&otf=2&iid=1dd3b944-fa62-4b55-b330-74909a99969e";
        $fields = array(
            'sl' => urlencode($source),
            'tl' => urlencode($target),
            'q' => urlencode($text)
        );
        $fields_string = "";
        foreach($fields as $key=>$value) {
            $fields_string .= $key.'='.$value.'&';
        }
        rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_ENCODING, 'UTF-8');
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_REFERER, "https://translate.google.com/?tr=f&hl=en");
        curl_setopt($ch, CURLOPT_USERAGENT, 'AndroidTranslate/5.3.0.RC02.130475354-53000263 5.1 phone TRANSLATE_OPM5_TEST_1');
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
    protected static function getSentencesFromJSON($json) {
        $sentencesArray = json_decode($json, true);
        $sentences = "";
        foreach ($sentencesArray["sentences"] as $s) {
            $sentences .= $s["trans"];
        }
        return $sentences;
    }
}

function content_func($key, $count, $cookies){
	$query = urlencode($key);
	$url = "https://search.aol.com/aol/search?q={$query}&v_t=comsearch&ei=UTF-8&s_chn=prt_bon&b=0&pz=20&bct=0&xargs=0";
	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_COOKIEJAR, $cookies);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36");
	curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
	curl_setopt($curl, CURLOPT_TIMEOUT, 5);
	$response = curl_exec($curl);
	curl_close($curl);
	$curl = curl_init($url);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_COOKIEFILE, $cookies);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36");
	curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
	curl_setopt($curl, CURLOPT_TIMEOUT, 5);
	$response = curl_exec($curl);
	curl_close($curl);
	$getstr = str_get_html($response);
	if(empty($getstr)){
		$has = "";
		$tag = "";
		$srcz = "";
		return json_encode(array("source" => "AOL","data" => $has,"tags" => $tag,"source" => $srcz), JSON_HEX_APOS | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	}else{
		if($getstr->find('ol.searchCenterFooter table td',0)){
			foreach($getstr->find('ol.searchCenterFooter table td') as $tagz){
				$tag .= trim(preg_replace('/\s{1,}/', ' ', seotext($tagz->plaintext))).', ';
			}
			$tag = rtrim($tag, ', ');
		}else{
			$tag = "";
		}
		$srcz = array();
		if($getstr->find('li h3 a.ac-algo',0)){
		    foreach($getstr->find('li h3 a.ac-algo') as $srcx){
		        $srcv = urldecode(preg_replace('/.*\/RU=|\/RK=0\/.*/', '', $srcx->href));
		        if(preg_match('/\.pinterest\.|\.facebook\.|\.youtube\.|\.twitter\.|\.instagram\.|\.tiktok\./', $srcv)){continue;}
		        $srcz[] = $srcv;
		    }
		}else{
			$srcz = "";
		}
		$has = array();
		if($getstr->find('li p.lh-16',0)){
			foreach($getstr->find('li p.lh-16') as $str){
				$hasx = trim(preg_replace('/\s{1,}/', ' ', seotext(html_entity_decode($str->plaintext))));
				$has[] = $hasx;
			}
			return json_encode(array("source" => "AOL","data" => $has,"tags" => $tag,"source" => $srcz), JSON_HEX_APOS | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		}else{
			$has = "";
			return json_encode(array("source" => "AOL","data" => $has,"tags" => $tag,"source" => $srcz), JSON_HEX_APOS | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
		}
	}
}

function parse_key($ifkeyx, $locale, $cookies){
    $urlr = "https://search.visymo.com/search?q={$ifkeyx}&locale={$locale}&rkb=i&rkln=5";
    $curl = curl_init($urlr);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookies);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36");
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($curl, CURLOPT_TIMEOUT, 5);
    $response = curl_exec($curl);
    curl_close($curl);
    $curl = curl_init($urlr);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookies);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36");
    curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
    curl_setopt($curl, CURLOPT_TIMEOUT, 5);
    $response = curl_exec($curl);
    curl_close($curl);
    return str_get_html($response);
}
ob_end_flush();
?>